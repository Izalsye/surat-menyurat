<?php

return [
    'created' => '已创建 :menu',
    'updated' => '已更新 :menu',
    'deleted' => '已删除 :menu',
    'report' => '报告将发送到您的电子邮箱',
];
