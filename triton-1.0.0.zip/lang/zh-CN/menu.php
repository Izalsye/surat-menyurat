<?php

return [
    "dashboard" => "仪表盘",
    "user" => "用户",
    "role" => "角色",
    "incoming_letter" => "收件信",
    "outgoing_letter" => "发件信",
    "disposition" => "处理意见",
    "letter_category" => "信件分类",
    "setting" => "设置",
    "profile" => "个人资料",
    "password" => "密码",
    "session" => "会话",
    "appearance" => "外观",
    "delete_account" => "删除账户",
    "logout" => "注销",
    "activity_log" => "活动日志",
    'no_disposition' => '尚未处理',
    'need_action' => '需要处理',
];
