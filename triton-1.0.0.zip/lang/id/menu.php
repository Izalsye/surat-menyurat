<?php

return [
    "dashboard" => "Dasbor",
    "user" => "Pengguna",
    "role" => "Jabatan",
    "incoming_letter" => "Surat Masuk",
    "outgoing_letter" => "Surat Keluar",
    "disposition" => "Disposisi",
    "letter_category" => "Kategori Surat",
    "setting" => "Pengaturan",
    "profile" => "Profil",
    "password" => "Kata Sandi",
    "session" => "Sesi",
    "appearance" => "Tampilan",
    "delete_account" => "Hapus Akun",
    "logout" => "Keluar",
    "activity_log" => "Log",
    "no_disposition" => "Belum diproses",
    "need_action" => "Perlu diproses",
];
