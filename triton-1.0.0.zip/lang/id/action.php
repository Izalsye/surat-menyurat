<?php

return [
    'created' => ':menu berhasil dibuat',
    'updated' => ':menu berhasil diperbarui',
    'deleted' => ':menu berhasil dihapus',
    'report' => 'Laporan akan dikirim ke email Anda',
];
