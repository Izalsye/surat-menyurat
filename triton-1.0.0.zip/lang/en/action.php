<?php

return [
    'created' => ':menu created',
    'updated' => ':menu updated',
    'deleted' => ':menu deleted',
    'report' => 'The report will be sent to your email',
];
