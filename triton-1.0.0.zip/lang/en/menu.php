<?php

return [
    "dashboard" => "Dashboard",
    "user" => "User",
    "role" => "Role",
    "incoming_letter" => "Incoming Letter",
    "outgoing_letter" => "Outgoing Letter",
    "disposition" => "Disposition",
    "letter_category" => "Letter Category",
    "setting" => "Settings",
    "profile" => "Profile",
    "password" => "Password",
    "session" => "Session",
    "appearance" => "Appearance",
    "delete_account" => "Delete Account",
    "logout" => "Logout",
    "activity_log" => "Activity Log",
    'no_disposition' => 'Not processed yet',
    'need_action' => 'Needs action',
];
