<?php

return [
    'created' => 'تم إنشاء :menu',
    'updated' => 'تم تحديث :menu',
    'deleted' => 'تم حذف :menu',
    'report' => 'سيتم إرسال التقرير إلى بريدك الإلكتروني',
];
