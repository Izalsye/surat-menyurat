<?php

return [
    "dashboard" => "لوحة التحكم",
    "user" => "المستخدم",
    "role" => "الدور",
    "incoming_letter" => "رسالة واردة",
    "outgoing_letter" => "رسالة صادرة",
    "disposition" => "التوجيه",
    "letter_category" => "فئة الرسائل",
    "setting" => "الإعدادات",
    "profile" => "الملف الشخصي",
    "password" => "كلمة المرور",
    "session" => "الجلسة",
    "appearance" => "المظهر",
    "delete_account" => "حذف الحساب",
    "logout" => "تسجيل الخروج",
    "activity_log" => "سجل الأنشطة",
    'no_disposition' => 'لم تتم المعالجة بعد',
    'need_action' => 'بحاجة إلى إجراء',
];
