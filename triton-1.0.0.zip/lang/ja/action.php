<?php

return [
    'created' => ':menu を作成しました',
    'updated' => ':menu を更新しました',
    'deleted' => ':menu を削除しました',
    'report' => 'レポートはあなたのメールに送信されます',
];
