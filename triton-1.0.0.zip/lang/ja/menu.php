<?php

return [
    "dashboard" => "ダッシュボード",
    "user" => "ユーザー",
    "role" => "役割",
    "incoming_letter" => "受信文書",
    "outgoing_letter" => "送信文書",
    "disposition" => "処理",
    "letter_category" => "文書カテゴリ",
    "setting" => "設定",
    "profile" => "プロフィール",
    "password" => "パスワード",
    "session" => "セッション",
    "appearance" => "外観",
    "delete_account" => "アカウント削除",
    "logout" => "ログアウト",
    "activity_log" => "アクティビティログ",
    'no_disposition' => '未処理',
    'need_action' => '対応が必要です',
];
