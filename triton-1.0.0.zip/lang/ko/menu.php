<?php

return [
    "dashboard" => "대시보드",
    "user" => "사용자",
    "role" => "역할",
    "incoming_letter" => "수신 문서",
    "outgoing_letter" => "발신 문서",
    "disposition" => "결재",
    "letter_category" => "문서 분류",
    "setting" => "설정",
    "profile" => "프로필",
    "password" => "비밀번호",
    "session" => "세션",
    "appearance" => "화면 설정",
    "delete_account" => "계정 삭제",
    "logout" => "로그아웃",
    "activity_log" => "활동 로그",
    'no_disposition' => '아직 처리되지 않음',
    'need_action' => '조치 필요',
];
