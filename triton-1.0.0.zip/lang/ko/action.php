<?php

return [
    'created' => ':menu 생성됨',
    'updated' => ':menu 업데이트됨',
    'deleted' => ':menu 삭제됨',
    'report' => '보고서가 귀하의 이메일로 전송됩니다',
];
