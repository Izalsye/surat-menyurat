<?php

return [
    'secret_key' => env('XENDIT_SECRET_KEY'),
];
