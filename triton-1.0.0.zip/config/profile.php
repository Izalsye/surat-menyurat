<?php

return [
    'company_name' => env('COMPANY_NAME', env('APP_NAME', 'Titania')),
    'address' => env('PROFILE_ADDRESS', 'Jl. Lorem Ipsum Dolor Sit Amet'),
    'email' => env('PROFILE_EMAIL', 'iqbaleff214@gmail.com'),
    'phone' => env('PROFILE_PHONE', '+62 812 345 6789'),
    'city' => env('PROFILE_CITY', 'Jakarta'),
];
