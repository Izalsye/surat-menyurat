<?php

namespace App\Http\Controllers;

use App\Enum\IncomingStatus;
use App\Http\Requests\IncomingLetter\StoreRequest;
use App\Http\Requests\IncomingLetter\UpdateRequest;
use App\Jobs\GenerateIncomingLetterReport;
use App\Models\IncomingLetter;
use App\Models\LetterCategory;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Inertia\Response;

class IncomingLetterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request): Response
    {
        $user = $request->user();
        return Inertia::render('incoming_letter/Index', [
            'items' => IncomingLetter::with([
                    'readers' => fn ($query) => $query->where('user_id', $user->id),
                    'letter_categories', 'dispositions', 'replies',
                ])
                ->latest()
                ->filter($request->query(), $user->id)
                ->render($request->query('size')),
            'categories' => LetterCategory::all(),
            'statuses' => IncomingStatus::values(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreRequest $request): RedirectResponse
    {
        try {
            $input = $request->validated();
            if ($input['letter_date']) {
                $input['letter_date'] = Carbon::parse($input['letter_date']);
            }
            $input['file'] = $input['file']->store('incoming_letter');
            $input['created_by'] = $request->user()->id;
            $letter = IncomingLetter::query()->create($input);
            if ($codes = $request->input('categories')) {
                $categories = LetterCategory::query()
                    ->whereIn('code', $codes)
                    ->pluck('id')->toArray();
                $letter->letter_categories()->attach($categories);
            }

            return back()->with('success', __('action.created', ['menu' => __('menu.incoming_letter')]));
        } catch (\Throwable $exception) {
            Log::error($exception->getMessage());

            return back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(IncomingLetter $letter): Response
    {
        $user = auth()->user();
        $alreadyRead = $letter->readers()->where('user_id', $user->id)->exists();
        if (!$alreadyRead) {
            $letter->readers()->attach($user->id, ['read_at' => now()]);
        }

        $letter->load([
            'letter_categories', 'replies',
            'dispositions' => fn ($query) => $query->whereNull('parent_id')->orderByDesc('created_at'),
            'dispositions.assigner', 'dispositions.assignee', 'dispositions.replies',
            'dispositions.children',
        ]);

        return Inertia::render('incoming_letter/Show', [
            'item' => $letter,
            'next' => IncomingLetter::query()
                ->where('created_at', '<', $letter->created_at)
                ->orderByDesc('created_at')
                ->limit(1)
                ->value('id'),
            'prev' => IncomingLetter::query()
                ->where('created_at', '>', $letter->created_at)
                ->orderBy('created_at')
                ->limit(1)
                ->value('id'),
            'total' => IncomingLetter::query()->count('id'),
            'index' => IncomingLetter::query()
                ->where('created_at', '>', $letter->created_at)
                ->orderByDesc('created_at')
                ->count('id') + 1,
            'categories' => LetterCategory::all(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateRequest $request, IncomingLetter $letter): RedirectResponse
    {
        try {
            $input = $request->validated();
            if ($input['letter_date']) {
                $input['letter_date'] = Carbon::parse($input['letter_date']);
            }
            $letter->update($input);
            if ($codes = $request->input('categories')) {
                $categories = LetterCategory::query()
                    ->whereIn('code', $codes)
                    ->pluck('id')->toArray();
                $letter->letter_categories()->sync($categories);
            }

            return back()->with('success', __('action.updated', ['menu' => __('menu.incoming_letter')]));;
        } catch (\Throwable $exception) {
            Log::error($exception->getMessage());

            return back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, IncomingLetter $letter): RedirectResponse
    {
        try {
            $nextId = $request->input('prev') ?? $request->input('next');
            $letter->delete();
            if ($nextId) {
                return redirect()
                    ->route('incoming-letter.show', $nextId)
                    ->with('success', __('action.deleted', ['menu' => __('menu.incoming_letter')]));
            }
            return redirect()->route('incoming-letter.index')
                ->with('success', __('action.deleted', ['menu' => __('menu.incoming_letter')]));
        } catch (\Throwable $exception) {
            Log::error($exception->getMessage());

            return back()->with('error', $exception->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function massDestroy(Request $request): RedirectResponse
    {
        try {
            $ids = $request->input('ids');
            if (empty($ids)) {
                throw new \Exception('Empty ids');
            }

            $files = IncomingLetter::query()
                ->whereIn('id', $ids)
                ->pluck('file')->toArray();
            foreach ($files as $file) {
                Storage::delete($file);
            }

            IncomingLetter::query()
                ->whereIn('id', $ids)
                ->delete();

            return back()->with('success', __('action.deleted', ['menu' => __('menu.incoming_letter')]));
        } catch (\Throwable $exception) {
            Log::error($exception->getMessage());

            return back()->with('error', $exception->getMessage());
        }
    }

    public function markAsUnread(Request $request, IncomingLetter $letter): RedirectResponse
    {
        try {
            $user = $request->user();
            $letter->readers()
                ->detach($user->id);

            if ($request->boolean('index')) {
                return redirect()->route('incoming-letter.index');
            }

            return back();
        } catch (\Throwable $exception) {
            Log::error($exception->getMessage());

            return back()->with('error', $exception->getMessage());
        }
    }

    public function massMarkAsUnread(Request $request): RedirectResponse
    {
        try {
            $ids = $request->input('ids');
            if (empty($ids)) {
                throw new \Exception('Empty ids');
            }

            $user = $request->user();
            $user->readLetters()
                ->detach($ids);

            return back();
        } catch (\Throwable $exception) {
            Log::error($exception->getMessage());

            return back()->with('error', $exception->getMessage());
        }
    }

    public function export(Request $request): RedirectResponse
    {
        try {
            $input = $request->all();
            $user = $request->user();

            GenerateIncomingLetterReport::dispatch($user, $input);

            return back()->with('success', __('action.report'));
        } catch (\Throwable $exception) {
            Log::error($exception->getMessage());
            return back()->with('error', $exception->getMessage());
        }
    }
}
